from pystata.config import check_initialized

check_initialized()
