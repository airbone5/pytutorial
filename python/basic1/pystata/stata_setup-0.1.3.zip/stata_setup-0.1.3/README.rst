
stata_setup 
===========

The **stata_setup** module is used to configure and initialize Stata within 
Python. After the initialization, you can use the 
`pystata <https://www.stata.com/python/pystata>`__ Python package, which is 
shipped with Stata 17, to interact Stata with Python. 

After the module is installed, you can type

  >>> import stata_setup
  >>> stata_setup.config('your_stata_installation_directory', 'your_stata_edition')

in your Python environment to initialize Stata. For example, if you have Stata 
installed in **C:\\Program Files\\Stata17\\** and you use the **Stata/MP*** edition,  
then Stata can be initialized as follows:

  >>> import stata_setup
  >>> stata_setup.config('C:/Program Files/Stata17/', 'mp')
  
If Stata is initialized correctly, it will return with a splash
screen with Stata's logo and initialization message.
To suppress these messages, set the **splash** argument to False, as
follows:

  >>> stata_setup.config('C:/Program Files/Stata17/', 'mp', splash=False)

See `Configuration <https://www.stata.com/python/pystata/install.html#method-1-installing-via-pip>`__ 
for more information on how to configure and initialize Stata from within 
Python. 

**stata_setup** runs with Python 2.7+ and 3.4+. 
